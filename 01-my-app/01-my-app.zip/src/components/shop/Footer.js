import React from "react";

const Footer = () => {
  return (
    <div className="bg-dark p-4 text-center text-light">
      &copy;2021 Copyright by Techpro Shop
    </div>
  );
};

export default Footer;
