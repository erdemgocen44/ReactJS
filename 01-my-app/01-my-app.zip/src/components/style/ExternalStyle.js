import "./ExternalStyle.css";

const ExternalStyle = () => {
  return (
    <div className="ozlusoz">
      hersey bir tecrübe hocam.. tecrübe paylasımları da önemli (Tahir Cesur)
    </div>
  );
};
export default ExternalStyle;
