const Comp = () => {
  return <div>Bu bir component tir (Comp)</div>;
};

export default Comp;
