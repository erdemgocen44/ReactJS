const Props = (props) => {
  return (
    <h1>
      {props.ad} {props.soyad} hoşgeldin
    </h1>
  );
};

export default Props;
