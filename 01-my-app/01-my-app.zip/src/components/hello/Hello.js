import Comp from "../comp/Comp";

const Hello = () => {
  return (
    <div>
      Bu benim ilk component im (Hello) <Comp />
    </div>
  );
};

export default Hello;
