const Test = () => {
  return <div>Bu bir test componenti dir. (Test)</div>;
};

export default Test;
